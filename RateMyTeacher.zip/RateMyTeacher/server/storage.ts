import { 
  schools, teachers, ratings, comments,
  type School, type Teacher, type Rating, type Comment,
  type InsertSchool, type InsertTeacher, type InsertRating, type InsertComment,
  type TeacherWithStats, type RankingEntry
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, gte } from "drizzle-orm";

export interface IStorage {
  // Schools
  getSchools(): Promise<School[]>;
  getSchool(id: number): Promise<School | undefined>;
  createSchool(school: Omit<InsertSchool, 'adminCode'>): Promise<School>;
  
  // Teachers
  getTeachers(schoolId?: number, subject?: string, search?: string): Promise<Teacher[]>;
  getTeacher(id: number): Promise<Teacher | undefined>;
  getTeacherWithStats(id: number): Promise<TeacherWithStats | undefined>;
  createTeacher(teacher: InsertTeacher): Promise<Teacher>;
  updateTeacherStats(teacherId: number): Promise<void>;
  incrementTeacherViews(teacherId: number): Promise<void>;
  
  // Admin - Teacher Management
  getPendingTeachers(): Promise<Teacher[]>;
  approveTeacher(teacherId: number): Promise<void>;
  rejectTeacher(teacherId: number): Promise<void>;
  
  // Ratings
  getRatings(teacherId: number): Promise<Rating[]>;
  createRating(rating: InsertRating): Promise<Rating>;
  canUserRate(teacherId: number, userFingerprint: string): Promise<boolean>;
  
  // Comments
  getComments(teacherId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  
  // Rankings and Stats
  getTopTeachers(limit?: number): Promise<RankingEntry[]>;
  getSchoolRankings(): Promise<Array<{ school: School; averageRating: number }>>;
  getWeeklyTopTeachers(): Promise<RankingEntry[]>;
}

export class DatabaseStorage implements IStorage {
  // Schools
  async getSchools(): Promise<School[]> {
    return await db.select().from(schools);
  }

  async getSchool(id: number): Promise<School | undefined> {
    const [school] = await db.select().from(schools).where(eq(schools.id, id));
    return school;
  }

  async createSchool(school: Omit<InsertSchool, 'adminCode'>): Promise<School> {
    const [newSchool] = await db
      .insert(schools)
      .values(school)
      .returning();
    return newSchool;
  }

  // Teachers
  async getTeachers(schoolId?: number, subject?: string, search?: string): Promise<Teacher[]> {
    const conditions = [eq(teachers.isApproved, 1)]; // Only approved teachers
    if (schoolId) conditions.push(eq(teachers.schoolId, schoolId));
    if (subject) conditions.push(eq(teachers.subject, subject));
    if (search) {
      conditions.push(
        sql`(${teachers.name} ILIKE ${`%${search}%`} OR ${teachers.subject} ILIKE ${`%${search}%`})`
      );
    }
    
    return await db
      .select()
      .from(teachers)
      .where(and(...conditions))
      .orderBy(desc(teachers.averageRating));
  }

  async getTeacher(id: number): Promise<Teacher | undefined> {
    const [teacher] = await db.select().from(teachers).where(eq(teachers.id, id));
    return teacher;
  }

  async getTeacherWithStats(id: number): Promise<TeacherWithStats | undefined> {
    const teacher = await this.getTeacher(id);
    if (!teacher) return undefined;

    const school = await this.getSchool(teacher.schoolId);
    const teacherRatings = await db.select().from(ratings).where(eq(ratings.teacherId, id));
    const teacherComments = await db.select().from(comments)
      .where(and(eq(comments.teacherId, id), eq(comments.isApproved, 1)))
      .orderBy(desc(comments.createdAt))
      .limit(5);

    // Calculate category averages
    const categoryAverages = {
      explainsWell: 0,
      fairGrading: 0,
      humorLevel: 0,
      homeworkAmount: 0,
      outfitRating: 0,
      chillFactor: 0,
    };

    if (teacherRatings.length > 0) {
      categoryAverages.explainsWell = teacherRatings.reduce((sum, r) => sum + r.explainsWell, 0) / teacherRatings.length;
      categoryAverages.fairGrading = teacherRatings.reduce((sum, r) => sum + r.fairGrading, 0) / teacherRatings.length;
      categoryAverages.humorLevel = teacherRatings.reduce((sum, r) => sum + r.humorLevel, 0) / teacherRatings.length;
      categoryAverages.homeworkAmount = teacherRatings.reduce((sum, r) => sum + r.homeworkAmount, 0) / teacherRatings.length;
      categoryAverages.outfitRating = teacherRatings.reduce((sum, r) => sum + r.outfitRating, 0) / teacherRatings.length;
      categoryAverages.chillFactor = teacherRatings.reduce((sum, r) => sum + r.chillFactor, 0) / teacherRatings.length;
    }

    return {
      ...teacher,
      commentCount: teacherComments.length,
      categoryAverages,
      schoolName: school?.name || "Unknown School",
      recentComments: teacherComments,
    };
  }

  async createTeacher(teacher: InsertTeacher): Promise<Teacher> {
    const [newTeacher] = await db
      .insert(teachers)
      .values({
        ...teacher,
        emoji: teacher.emoji || "👨‍🏫",
        averageRating: 0,
        totalRatings: 0,
        views: 0,
        lastRated: null,
        isApproved: 0, // Pending approval by default
        submittedAt: new Date(),
      })
      .returning();
    return newTeacher;
  }

  // Admin - Teacher Management
  async getPendingTeachers(): Promise<Teacher[]> {
    return await db
      .select()
      .from(teachers)
      .where(eq(teachers.isApproved, 0))
      .orderBy(desc(teachers.submittedAt));
  }

  async approveTeacher(teacherId: number): Promise<void> {
    await db
      .update(teachers)
      .set({ isApproved: 1 })
      .where(eq(teachers.id, teacherId));
  }

  async rejectTeacher(teacherId: number): Promise<void> {
    await db
      .delete(teachers)
      .where(eq(teachers.id, teacherId));
  }

  async updateTeacherStats(teacherId: number): Promise<void> {
    const teacherRatings = await db.select().from(ratings).where(eq(ratings.teacherId, teacherId));
    
    if (teacherRatings.length > 0) {
      const totalScore = teacherRatings.reduce((sum, rating) => {
        return sum + (rating.explainsWell + rating.fairGrading + rating.humorLevel + 
                     rating.outfitRating + rating.chillFactor + (6 - rating.homeworkAmount)) / 6;
      }, 0);
      
      const averageRating = Math.round((totalScore / teacherRatings.length) * 10) / 10;
      
      await db
        .update(teachers)
        .set({
          averageRating,
          totalRatings: teacherRatings.length,
          lastRated: new Date(),
        })
        .where(eq(teachers.id, teacherId));
    }
  }

  async incrementTeacherViews(teacherId: number): Promise<void> {
    await db
      .update(teachers)
      .set({
        views: sql`${teachers.views} + 1`,
      })
      .where(eq(teachers.id, teacherId));
  }

  // Ratings
  async getRatings(teacherId: number): Promise<Rating[]> {
    return await db.select().from(ratings).where(eq(ratings.teacherId, teacherId));
  }

  async createRating(rating: InsertRating): Promise<Rating> {
    const [newRating] = await db
      .insert(ratings)
      .values({
        ...rating,
        ratedAt: new Date(),
        isApproved: 1,
      })
      .returning();
    
    // Update teacher stats
    await this.updateTeacherStats(rating.teacherId);
    
    return newRating;
  }

  async canUserRate(teacherId: number, userFingerprint: string): Promise<boolean> {
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const [recentRating] = await db
      .select()
      .from(ratings)
      .where(
        and(
          eq(ratings.teacherId, teacherId),
          eq(ratings.userFingerprint, userFingerprint),
          gte(ratings.ratedAt, oneWeekAgo)
        )
      )
      .limit(1);
    
    return !recentRating;
  }

  // Comments
  async getComments(teacherId: number): Promise<Comment[]> {
    return await db
      .select()
      .from(comments)
      .where(and(eq(comments.teacherId, teacherId), eq(comments.isApproved, 1)))
      .orderBy(desc(comments.createdAt));
  }

  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db
      .insert(comments)
      .values({
        ...comment,
        createdAt: new Date(),
        isApproved: 1,
      })
      .returning();
    return newComment;
  }

  // Rankings and Stats
  async getTopTeachers(limit = 5): Promise<RankingEntry[]> {
    const topTeachers = await db
      .select()
      .from(teachers)
      .where(sql`${teachers.totalRatings} > 0`)
      .orderBy(desc(teachers.averageRating))
      .limit(limit);

    const result: RankingEntry[] = [];
    for (const teacher of topTeachers) {
      const school = await this.getSchool(teacher.schoolId);
      if (school) {
        result.push({
          teacher,
          school,
          rankChange: Math.floor(Math.random() * 20) - 10, // Simulated rank change
        });
      }
    }

    return result;
  }

  async getSchoolRankings(): Promise<Array<{ school: School; averageRating: number }>> {
    const schoolRankings = await db
      .select({
        school: schools,
        averageRating: sql<number>`ROUND(AVG(${teachers.averageRating}), 1)`,
      })
      .from(schools)
      .leftJoin(teachers, eq(schools.id, teachers.schoolId))
      .where(sql`${teachers.totalRatings} > 0`)
      .groupBy(schools.id)
      .orderBy(desc(sql`AVG(${teachers.averageRating})`));

    return schoolRankings;
  }

  async getWeeklyTopTeachers(): Promise<RankingEntry[]> {
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    
    const weeklyRatings = await db
      .select({
        teacherId: ratings.teacherId,
        averageScore: sql<number>`AVG((${ratings.explainsWell} + ${ratings.fairGrading} + ${ratings.humorLevel} + ${ratings.outfitRating} + ${ratings.chillFactor} + (6 - ${ratings.homeworkAmount})) / 6.0)`,
      })
      .from(ratings)
      .where(gte(ratings.ratedAt, oneWeekAgo))
      .groupBy(ratings.teacherId)
      .orderBy(desc(sql`AVG((${ratings.explainsWell} + ${ratings.fairGrading} + ${ratings.humorLevel} + ${ratings.outfitRating} + ${ratings.chillFactor} + (6 - ${ratings.homeworkAmount})) / 6.0)`))
      .limit(5);

    const result: RankingEntry[] = [];
    for (const rating of weeklyRatings) {
      const teacher = await this.getTeacher(rating.teacherId);
      if (teacher) {
        const school = await this.getSchool(teacher.schoolId);
        if (school) {
          result.push({
            teacher,
            school,
            rankChange: Math.floor(Math.random() * 20) - 5,
          });
        }
      }
    }

    return result;
  }
}

export const storage = new DatabaseStorage();
