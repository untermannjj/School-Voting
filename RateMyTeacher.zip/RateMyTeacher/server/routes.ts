import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertRatingSchema, insertTeacherSchema, insertCommentSchema, insertSchoolSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Schools
  app.get("/api/schools", async (req, res) => {
    try {
      const schools = await storage.getSchools();
      res.json(schools);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch schools" });
    }
  });

  // Teachers
  app.get("/api/teachers", async (req, res) => {
    try {
      const { schoolId, subject, search } = req.query;
      const teachers = await storage.getTeachers(
        schoolId ? parseInt(schoolId as string) : undefined,
        subject as string,
        search as string
      );
      res.json(teachers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch teachers" });
    }
  });

  app.get("/api/teachers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.incrementTeacherViews(id);
      const teacher = await storage.getTeacherWithStats(id);
      
      if (!teacher) {
        return res.status(404).json({ message: "Teacher not found" });
      }
      
      res.json(teacher);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch teacher" });
    }
  });

  app.post("/api/schools", async (req, res) => {
    try {
      const { adminCode, ...schoolData } = insertSchoolSchema.parse(req.body);
      
      // Simple admin code verification
      if (adminCode !== "SCHOOL2024") {
        return res.status(403).json({ message: "Ungültiger Admin-Code" });
      }
      
      const newSchool = await storage.createSchool(schoolData);
      res.status(201).json(newSchool);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid school data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create school" });
    }
  });

  app.post("/api/teachers", async (req, res) => {
    try {
      const teacherData = insertTeacherSchema.parse(req.body);
      
      const newTeacher = await storage.createTeacher(teacherData);
      res.status(201).json({ 
        ...newTeacher, 
        message: "Lehrer eingereicht und wartet auf Genehmigung" 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid teacher data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create teacher" });
    }
  });

  // Admin routes for teacher management
  app.get("/api/admin/pending-teachers", async (req, res) => {
    try {
      const { adminCode } = req.query;
      
      if (adminCode !== "ADMIN2024") {
        return res.status(403).json({ message: "Ungültiger Admin-Code" });
      }
      
      const pendingTeachers = await storage.getPendingTeachers();
      
      // Add school information
      const teachersWithSchools = await Promise.all(
        pendingTeachers.map(async (teacher) => {
          const school = await storage.getSchool(teacher.schoolId);
          return { ...teacher, school };
        })
      );
      
      res.json(teachersWithSchools);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch pending teachers" });
    }
  });

  app.post("/api/admin/approve-teacher/:id", async (req, res) => {
    try {
      const { adminCode } = req.body;
      
      if (adminCode !== "ADMIN2024") {
        return res.status(403).json({ message: "Ungültiger Admin-Code" });
      }
      
      const teacherId = parseInt(req.params.id);
      await storage.approveTeacher(teacherId);
      res.json({ message: "Lehrer genehmigt" });
    } catch (error) {
      res.status(500).json({ message: "Failed to approve teacher" });
    }
  });

  app.post("/api/admin/reject-teacher/:id", async (req, res) => {
    try {
      const { adminCode } = req.body;
      
      if (adminCode !== "ADMIN2024") {
        return res.status(403).json({ message: "Ungültiger Admin-Code" });
      }
      
      const teacherId = parseInt(req.params.id);
      await storage.rejectTeacher(teacherId);
      res.json({ message: "Lehrer abgelehnt" });
    } catch (error) {
      res.status(500).json({ message: "Failed to reject teacher" });
    }
  });

  // Ratings
  app.post("/api/ratings", async (req, res) => {
    try {
      const ratingData = insertRatingSchema.parse(req.body);
      
      // Simple fingerprinting for rate limiting (in production, use more sophisticated methods)
      const userFingerprint = req.headers['x-forwarded-for'] || req.connection.remoteAddress || 'unknown';
      const fingerprintHash = Buffer.from(userFingerprint.toString()).toString('base64');
      
      // Check if user can rate (once per week)
      const canRate = await storage.canUserRate(ratingData.teacherId, fingerprintHash);
      if (!canRate) {
        return res.status(429).json({ message: "Du kannst diesen Lehrer nur einmal pro Woche bewerten" });
      }
      
      const rating = await storage.createRating({
        ...ratingData,
        userFingerprint: fingerprintHash,
      });
      
      res.status(201).json(rating);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid rating data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to submit rating" });
    }
  });

  // Comments
  app.get("/api/teachers/:id/comments", async (req, res) => {
    try {
      const teacherId = parseInt(req.params.id);
      const comments = await storage.getComments(teacherId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  app.post("/api/comments", async (req, res) => {
    try {
      const comment = insertCommentSchema.parse(req.body);
      const newComment = await storage.createComment(comment);
      res.status(201).json(newComment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid comment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  // Rankings
  app.get("/api/rankings/top-teachers", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const rankings = await storage.getTopTeachers(limit);
      res.json(rankings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rankings" });
    }
  });

  app.get("/api/rankings/weekly-top", async (req, res) => {
    try {
      const rankings = await storage.getWeeklyTopTeachers();
      res.json(rankings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch weekly rankings" });
    }
  });

  app.get("/api/rankings/schools", async (req, res) => {
    try {
      const rankings = await storage.getSchoolRankings();
      res.json(rankings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch school rankings" });
    }
  });

  // Subjects (for filter dropdown)
  app.get("/api/subjects", async (req, res) => {
    try {
      const teachers = await storage.getTeachers();
      const subjects = Array.from(new Set(teachers.map(t => t.subject))).sort();
      res.json(subjects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch subjects" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
