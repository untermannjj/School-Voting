import { pgTable, text, serial, integer, real, timestamp, json, varchar, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const schools = pgTable("schools", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location").notNull(),
  code: text("code").unique(),
});

export const teachers = pgTable("teachers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  subject: text("subject").notNull(),
  emoji: text("emoji").notNull().default("👨‍🏫"),
  schoolId: integer("school_id").notNull(),
  averageRating: real("average_rating").default(0),
  totalRatings: integer("total_ratings").default(0),
  views: integer("views").default(0),
  lastRated: timestamp("last_rated"),
  isApproved: integer("is_approved").default(0), // 0 = pending, 1 = approved
  submittedAt: timestamp("submitted_at").defaultNow(),
});

export const ratings = pgTable("ratings", {
  id: serial("id").primaryKey(),
  teacherId: integer("teacher_id").notNull(),
  schoolId: integer("school_id").notNull(),
  // Rating categories (1-5 stars)
  explainsWell: integer("explains_well").notNull(), // Erklärt gut
  fairGrading: integer("fair_grading").notNull(), // Fair bei Noten
  humorLevel: integer("humor_level").notNull(), // Humorlevel
  homeworkAmount: integer("homework_amount").notNull(), // Hausaufgaben-Hölle (1=wenig, 5=viel)
  outfitRating: integer("outfit_rating").notNull(), // Outfit des Tages
  chillFactor: integer("chill_factor").notNull(), // Chill-Faktor
  comment: text("comment"),
  isApproved: integer("is_approved").default(1), // Basic moderation
  ratedAt: timestamp("rated_at").defaultNow(),
  // Anonymous tracking for rate limiting
  userFingerprint: text("user_fingerprint"), // Simple hash for rate limiting
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  teacherId: integer("teacher_id").notNull(),
  content: text("content").notNull(),
  isApproved: integer("is_approved").default(1),
  createdAt: timestamp("created_at").defaultNow(),
});

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: json("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Relations
export const schoolsRelations = relations(schools, ({ many }) => ({
  teachers: many(teachers),
  ratings: many(ratings),
}));

export const teachersRelations = relations(teachers, ({ one, many }) => ({
  school: one(schools, {
    fields: [teachers.schoolId],
    references: [schools.id],
  }),
  ratings: many(ratings),
  comments: many(comments),
}));

export const ratingsRelations = relations(ratings, ({ one }) => ({
  teacher: one(teachers, {
    fields: [ratings.teacherId],
    references: [teachers.id],
  }),
  school: one(schools, {
    fields: [ratings.schoolId],
    references: [schools.id],
  }),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  teacher: one(teachers, {
    fields: [comments.teacherId],
    references: [teachers.id],
  }),
}));

// Insert schemas
export const insertSchoolSchema = createInsertSchema(schools).omit({
  id: true,
}).extend({
  adminCode: z.string().min(6, "Admin-Code muss mindestens 6 Zeichen haben"),
});

export const insertTeacherSchema = createInsertSchema(teachers).omit({
  id: true,
  averageRating: true,
  totalRatings: true,
  views: true,
  lastRated: true,
  isApproved: true,
  submittedAt: true,
});

export const insertRatingSchema = createInsertSchema(ratings).omit({
  id: true,
  ratedAt: true,
  isApproved: true,
}).extend({
  explainsWell: z.number().min(1).max(5),
  fairGrading: z.number().min(1).max(5),
  humorLevel: z.number().min(1).max(5),
  homeworkAmount: z.number().min(1).max(5),
  outfitRating: z.number().min(1).max(5),
  chillFactor: z.number().min(1).max(5),
  comment: z.string().max(500).optional(),
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  createdAt: true,
  isApproved: true,
});

// Types
export type School = typeof schools.$inferSelect;
export type Teacher = typeof teachers.$inferSelect;
export type Rating = typeof ratings.$inferSelect;
export type Comment = typeof comments.$inferSelect;

export type InsertSchool = z.infer<typeof insertSchoolSchema>;
export type InsertTeacher = z.infer<typeof insertTeacherSchema>;
export type InsertRating = z.infer<typeof insertRatingSchema>;
export type InsertComment = z.infer<typeof insertCommentSchema>;

// Extended types for API responses
export type TeacherWithStats = Teacher & {
  commentCount: number;
  categoryAverages: {
    explainsWell: number;
    fairGrading: number;
    humorLevel: number;
    homeworkAmount: number;
    outfitRating: number;
    chillFactor: number;
  };
  schoolName: string;
  recentComments: Comment[];
};

export type RankingEntry = {
  teacher: Teacher;
  school: School;
  rankChange: number;
};
