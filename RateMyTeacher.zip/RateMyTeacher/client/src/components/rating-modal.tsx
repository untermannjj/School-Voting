import { useState } from "react";
import { X, Star } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { InteractiveStarRating } from "./star-rating";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { getCategoryIcon, getCategoryLabel, generateUserFingerprint, getGradientClass } from "@/lib/utils";
import type { Teacher, InsertRating } from "@shared/schema";

interface RatingModalProps {
  isOpen: boolean;
  onClose: () => void;
  teacher: Teacher | null;
}

interface RatingData {
  explainsWell: number;
  fairGrading: number;
  humorLevel: number;
  homeworkAmount: number;
  outfitRating: number;
  chillFactor: number;
  comment: string;
}

export function RatingModal({ isOpen, onClose, teacher }: RatingModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [ratings, setRatings] = useState<RatingData>({
    explainsWell: 0,
    fairGrading: 0,
    humorLevel: 0,
    homeworkAmount: 0,
    outfitRating: 0,
    chillFactor: 0,
    comment: '',
  });

  const submitRatingMutation = useMutation({
    mutationFn: async (ratingData: InsertRating) => {
      const response = await apiRequest('POST', '/api/ratings', ratingData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Bewertung eingereicht!",
        description: "Deine Bewertung wurde erfolgreich gespeichert.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/teachers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/rankings'] });
      onClose();
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Fehler",
        description: error.message || "Die Bewertung konnte nicht gespeichert werden.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setRatings({
      explainsWell: 0,
      fairGrading: 0,
      humorLevel: 0,
      homeworkAmount: 0,
      outfitRating: 0,
      chillFactor: 0,
      comment: '',
    });
  };

  const handleRatingChange = (category: keyof RatingData, value: number) => {
    setRatings(prev => ({ ...prev, [category]: value }));
  };

  const handleSubmit = () => {
    if (!teacher) return;
    
    // Validate that at least some ratings are provided
    const ratingValues = [
      ratings.explainsWell,
      ratings.fairGrading,
      ratings.humorLevel,
      ratings.homeworkAmount,
      ratings.outfitRating,
      ratings.chillFactor
    ];
    
    if (ratingValues.every(rating => rating === 0)) {
      toast({
        title: "Bewertung unvollständig",
        description: "Bitte bewerte mindestens eine Kategorie.",
        variant: "destructive",
      });
      return;
    }

    const ratingData: InsertRating = {
      teacherId: teacher.id,
      schoolId: teacher.schoolId,
      explainsWell: ratings.explainsWell || 3,
      fairGrading: ratings.fairGrading || 3,
      humorLevel: ratings.humorLevel || 3,
      homeworkAmount: ratings.homeworkAmount || 3,
      outfitRating: ratings.outfitRating || 3,
      chillFactor: ratings.chillFactor || 3,
      comment: ratings.comment.trim() || undefined,
      userFingerprint: generateUserFingerprint(),
    };

    submitRatingMutation.mutate(ratingData);
  };

  if (!teacher) return null;

  const categories = [
    { key: 'explainsWell', label: 'Wie gut erklärt der Lehrer?', icon: '💡' },
    { key: 'fairGrading', label: 'Wie fair ist er bei Noten?', icon: '⚖️' },
    { key: 'humorLevel', label: 'Wie lustig ist der Unterricht?', icon: '😄' },
    { key: 'homeworkAmount', label: 'Wie viele Hausaufgaben gibt es?', icon: '📝', note: '1 = wenig, 5 = sehr viel' },
    { key: 'outfitRating', label: 'Wie ist das Outfit?', icon: '👗' },
    { key: 'chillFactor', label: 'Wie chill ist der Lehrer?', icon: '😎' },
  ];

  const subjectIndex = teacher.subject.charCodeAt(0) % 6;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Lehrer bewerten</DialogTitle>
        </DialogHeader>
        
        {/* Teacher Info */}
        <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
          <div className={`w-12 h-12 ${getGradientClass(subjectIndex)} rounded-xl flex items-center justify-center text-xl`}>
            {teacher.emoji}
          </div>
          <div>
            <h4 className="font-medium text-dark">{teacher.name}</h4>
            <p className="text-sm text-gray-500">{teacher.subject}</p>
          </div>
        </div>
        
        {/* Rating Categories */}
        <div className="space-y-6">
          {categories.map(({ key, label, icon, note }) => (
            <div key={key}>
              <Label className="flex items-center space-x-2 mb-3">
                <span className="text-lg">{icon}</span>
                <span className="font-medium text-gray-700">{label}</span>
              </Label>
              <InteractiveStarRating
                value={ratings[key as keyof RatingData] as number}
                onChange={(value) => handleRatingChange(key as keyof RatingData, value)}
              />
              {note && <p className="text-xs text-gray-500 mt-1">{note}</p>}
            </div>
          ))}
        </div>
        
        {/* Comment Section */}
        <div className="mt-6">
          <Label className="block font-medium text-gray-700 mb-2">
            Kommentar (optional)
          </Label>
          <Textarea
            value={ratings.comment}
            onChange={(e) => setRatings(prev => ({ ...prev, comment: e.target.value }))}
            placeholder="Was möchtest du anderen über diesen Lehrer sagen? (Bitte respektvoll bleiben)"
            rows={3}
            maxLength={500}
            className="resize-none"
          />
          <p className="text-xs text-gray-500 mt-1">
            Alle Kommentare werden moderiert
          </p>
        </div>
        
        {/* Action Buttons */}
        <div className="flex space-x-3 mt-6">
          <Button 
            variant="outline" 
            onClick={onClose} 
            className="flex-1"
            disabled={submitRatingMutation.isPending}
          >
            Abbrechen
          </Button>
          <Button 
            onClick={handleSubmit}
            className="flex-1 bg-primary hover:bg-primary/90"
            disabled={submitRatingMutation.isPending}
          >
            {submitRatingMutation.isPending ? "Wird gespeichert..." : "Bewertung abgeben"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
