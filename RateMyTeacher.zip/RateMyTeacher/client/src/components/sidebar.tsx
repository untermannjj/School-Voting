import { Trophy, Award, Zap, Crown, Swords } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { StarRating } from "./star-rating";
import { formatRating, getGradientClass } from "@/lib/utils";
import type { RankingEntry } from "@shared/schema";

export function Sidebar() {
  const { data: weeklyTop = [] } = useQuery<RankingEntry[]>({
    queryKey: ["/api/rankings/weekly-top"],
  });

  const { data: schoolRankings = [] } = useQuery<Array<{ school: any; averageRating: number }>>({
    queryKey: ["/api/rankings/schools"],
  });

  const awards = [
    {
      icon: "🎯",
      title: "Coolster Lehrer",
      teacher: weeklyTop[0]?.teacher.name || "Herr Wagner",
      subject: weeklyTop[0]?.teacher.subject || "Sport",
      period: "Diese Woche",
      color: "border-accent bg-accent/10"
    },
    {
      icon: "👑",
      title: "Mememaster",
      teacher: "Frau Müller",
      subject: "Deutsch",
      period: "Dieser Monat",
      color: "border-secondary bg-secondary/10"
    },
    {
      icon: "⚡",
      title: "Härtester Korrektor",
      teacher: "Dr. Fischer",
      subject: "Chemie",
      period: "Dieser Monat",
      color: "border-destructive bg-destructive/10"
    }
  ];

  return (
    <div className="space-y-6">
      {/* Weekly Top 5 */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center text-lg">
            <Trophy className="w-5 h-5 mr-2 text-secondary" />
            Top 5 der Woche
          </CardTitle>
          <span className="text-xs text-gray-500">Diese Woche</span>
        </CardHeader>
        <CardContent className="space-y-3">
          {weeklyTop.slice(0, 5).map((entry, index) => (
            <div 
              key={entry.teacher.id}
              className={`flex items-center space-x-3 p-3 rounded-lg ${
                index === 0 ? 'bg-gradient-to-r from-secondary/10 to-transparent' : 'bg-gray-50'
              }`}
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold ${
                index === 0 ? 'bg-secondary' : 'bg-gray-400'
              }`}>
                {index + 1}
              </div>
              <div className="flex-1">
                <p className="font-medium text-sm">{entry.teacher.name}</p>
                <p className="text-xs text-gray-500">
                  {entry.teacher.subject} • {formatRating(entry.teacher.averageRating || 0)} ⭐
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-500">
                  {entry.rankChange > 0 ? '+' : ''}{entry.rankChange}
                </p>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Awards Section */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center text-lg">
            <Award className="w-5 h-5 mr-2 text-accent" />
            Aktuelle Awards
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {awards.map((award, index) => (
            <div key={index} className={`p-4 rounded-lg border-l-4 ${award.color}`}>
              <div className="flex items-center space-x-2 mb-2">
                <span className="text-lg">{award.icon}</span>
                <span className="font-medium text-sm">{award.title}</span>
              </div>
              <p className="text-sm text-gray-600">{award.teacher}</p>
              <p className="text-xs text-gray-500">{award.subject} • {award.period}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* School Battle */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center text-lg">
            <Swords className="w-5 h-5 mr-2 text-primary" />
            School Battle
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {schoolRankings.slice(0, 3).map((ranking, index) => {
            const percentage = (ranking.averageRating / 5) * 100;
            const colors = ['bg-primary', 'bg-accent', 'bg-secondary'];
            
            return (
              <div key={ranking.school.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className={`w-6 h-6 ${colors[index]} rounded-full`}></div>
                  <span className="text-sm font-medium">{ranking.school.name}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-600">{formatRating(ranking.averageRating)}</span>
                  <div className="w-20 h-2 bg-gray-200 rounded-full">
                    <div 
                      className={`h-2 ${colors[index]} rounded-full transition-all duration-300`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
          
          <Button variant="outline" className="w-full mt-4 text-sm">
            Alle Schulen anzeigen
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
