import { useState } from "react";
import { GraduationCap, Plus, Building, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { AddSchoolModal } from "./add-school-modal";
import { AddTeacherModal } from "./add-teacher-modal";
import type { School } from "@shared/schema";

interface HeaderProps {
  selectedSchool: number | null;
  onSchoolChange: (schoolId: number) => void;
  onRateClick: () => void;
}

export function Header({ selectedSchool, onSchoolChange, onRateClick }: HeaderProps) {
  const [addSchoolOpen, setAddSchoolOpen] = useState(false);
  const [addTeacherOpen, setAddTeacherOpen] = useState(false);
  
  const { data: schools = [] } = useQuery<School[]>({
    queryKey: ["/api/schools"],
  });

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                <GraduationCap className="text-white w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-dark">RateMyTeacher</h1>
                <p className="text-xs text-gray-500">Schüler Edition</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Select 
              value={selectedSchool?.toString()} 
              onValueChange={(value) => onSchoolChange(parseInt(value))}
            >
              <SelectTrigger className="w-48 bg-gray-50 border-gray-200">
                <SelectValue placeholder="Schule wählen" />
              </SelectTrigger>
              <SelectContent>
                {schools.map((school) => (
                  <SelectItem key={school.id} value={school.id.toString()}>
                    {school.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button 
              onClick={onRateClick}
              className="bg-primary hover:bg-primary/90 text-white px-4 py-2"
            >
              <Plus className="w-4 h-4 mr-2" />
              Bewerten
            </Button>
            
            <Button 
              onClick={() => setAddSchoolOpen(true)}
              variant="outline" 
              className="text-gray-600 border-gray-300 hover:bg-gray-50"
            >
              <Building className="w-4 h-4 mr-2" />
              Schule hinzufügen
            </Button>
            
            <Button 
              onClick={() => setAddTeacherOpen(true)}
              variant="outline" 
              className="text-gray-600 border-gray-300 hover:bg-gray-50"
            >
              <UserPlus className="w-4 h-4 mr-2" />
              Lehrer hinzufügen
            </Button>
          </div>
        </div>
      </div>
      
      <AddSchoolModal 
        isOpen={addSchoolOpen} 
        onClose={() => setAddSchoolOpen(false)} 
      />
      
      <AddTeacherModal 
        isOpen={addTeacherOpen} 
        onClose={() => setAddTeacherOpen(false)} 
      />
    </header>
  );
}
