import { Star, StarHalf } from "lucide-react";
import { cn } from "@/lib/utils";

interface StarRatingProps {
  rating: number;
  size?: "sm" | "md" | "lg";
  interactive?: boolean;
  onRatingChange?: (rating: number) => void;
  className?: string;
}

export function StarRating({ 
  rating, 
  size = "md", 
  interactive = false, 
  onRatingChange,
  className 
}: StarRatingProps) {
  const sizeClasses = {
    sm: "w-3 h-3",
    md: "w-4 h-4",
    lg: "w-5 h-5"
  };

  const renderStars = () => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating - fullStars >= 0.5;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

    // Full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star
          key={`full-${i}`}
          className={cn(
            sizeClasses[size],
            "fill-secondary text-secondary",
            interactive && "cursor-pointer hover:scale-110 transition-transform"
          )}
          onClick={() => interactive && onRatingChange?.(i + 1)}
        />
      );
    }

    // Half star
    if (hasHalfStar) {
      stars.push(
        <StarHalf
          key="half"
          className={cn(
            sizeClasses[size],
            "fill-secondary text-secondary",
            interactive && "cursor-pointer hover:scale-110 transition-transform"
          )}
          onClick={() => interactive && onRatingChange?.(fullStars + 1)}
        />
      );
    }

    // Empty stars
    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <Star
          key={`empty-${i}`}
          className={cn(
            sizeClasses[size],
            "text-gray-300",
            interactive && "cursor-pointer hover:scale-110 transition-transform hover:text-secondary"
          )}
          onClick={() => interactive && onRatingChange?.(fullStars + (hasHalfStar ? 1 : 0) + i + 1)}
        />
      );
    }

    return stars;
  };

  return (
    <div className={cn("flex items-center space-x-1", className)}>
      {renderStars()}
    </div>
  );
}

interface InteractiveStarRatingProps {
  value: number;
  onChange: (value: number) => void;
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function InteractiveStarRating({ 
  value, 
  onChange, 
  size = "md", 
  className 
}: InteractiveStarRatingProps) {
  const sizeClasses = {
    sm: "w-6 h-6",
    md: "w-8 h-8",
    lg: "w-10 h-10"
  };

  return (
    <div className={cn("flex items-center space-x-2", className)}>
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          onClick={() => onChange(star)}
          className={cn(
            sizeClasses[size],
            "rounded-full border-2 transition-all duration-200 flex items-center justify-center",
            value >= star
              ? "bg-secondary border-secondary text-white"
              : "border-gray-200 hover:border-secondary hover:bg-secondary hover:text-white"
          )}
        >
          <Star className="w-3 h-3 fill-current" />
        </button>
      ))}
    </div>
  );
}
