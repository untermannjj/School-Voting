import { Eye, MessageCircle, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { StarRating } from "./star-rating";
import { formatRating, formatTimeAgo, getCategoryIcon, getCategoryLabel, getGradientClass, getBadgeColor, getBadgeText } from "@/lib/utils";
import type { Teacher } from "@shared/schema";

interface TeacherCardProps {
  teacher: Teacher & {
    commentCount: number;
    categoryAverages: {
      explainsWell: number;
      fairGrading: number;
      humorLevel: number;
      homeworkAmount: number;
      outfitRating: number;
      chillFactor: number;
    };
  };
  onClick: () => void;
}

export function TeacherCard({ teacher, onClick }: TeacherCardProps) {
  const categories = [
    { key: 'explainsWell', value: teacher.categoryAverages.explainsWell },
    { key: 'fairGrading', value: teacher.categoryAverages.fairGrading },
    { key: 'humorLevel', value: teacher.categoryAverages.humorLevel },
    { key: 'chillFactor', value: teacher.categoryAverages.chillFactor }
  ];

  const subjectIndex = teacher.subject.charCodeAt(0) % 6;
  const badgeColor = getBadgeColor(teacher.averageRating || 0);
  const badgeText = getBadgeText(teacher.averageRating || 0);

  return (
    <Card 
      className="hover:shadow-md transition-shadow cursor-pointer border-gray-100"
      onClick={onClick}
    >
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-4">
            <div className={`w-16 h-16 ${getGradientClass(subjectIndex)} rounded-2xl flex items-center justify-center text-2xl`}>
              {teacher.emoji}
            </div>
            <div>
              <h3 className="font-semibold text-dark text-lg">{teacher.name}</h3>
              <p className="text-gray-500 text-sm">{teacher.subject}</p>
              <div className="flex items-center mt-1">
                <StarRating rating={teacher.averageRating || 0} size="sm" />
                <span className="ml-2 text-sm text-gray-600">
                  {formatRating(teacher.averageRating || 0)}
                </span>
                <span className="ml-1 text-xs text-gray-400">
                  ({teacher.totalRatings} Bewertungen)
                </span>
              </div>
            </div>
          </div>
          <div className="flex flex-col items-end space-y-1">
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${badgeColor}`}>
              {badgeText}
            </span>
            <span className="text-xs text-gray-400">
              {teacher.lastRated ? formatTimeAgo(new Date(teacher.lastRated)) : 'Keine Bewertungen'}
            </span>
          </div>
        </div>
        
        {/* Rating Categories */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          {categories.map(({ key, value }, index) => (
            <div key={key} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-2">
                <span className="text-lg">{getCategoryIcon(key)}</span>
                <span className="text-sm text-gray-600">{getCategoryLabel(key)}</span>
              </div>
              <StarRating rating={value} size="sm" />
            </div>
          ))}
        </div>
        
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div className="flex items-center space-x-4 text-sm text-gray-500">
            <span>
              <MessageCircle className="w-4 h-4 inline mr-1" />
              {teacher.commentCount || 0} Kommentare
            </span>
            <span>
              <Eye className="w-4 h-4 inline mr-1" />
              {teacher.views || 0} Views
            </span>
          </div>
          <button className="text-primary hover:text-primary/80 text-sm font-medium flex items-center">
            Profil ansehen
            <ArrowRight className="w-4 h-4 ml-1" />
          </button>
        </div>
      </CardContent>
    </Card>
  );
}
