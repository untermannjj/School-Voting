import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { getSubjectEmoji } from "@/lib/utils";
import type { InsertTeacher, School } from "@shared/schema";

interface AddTeacherModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AddTeacherModal({ isOpen, onClose }: AddTeacherModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    name: "",
    subject: "",
    emoji: "",
    schoolId: "",
  });

  const { data: schools = [] } = useQuery<School[]>({
    queryKey: ["/api/schools"],
  });

  const subjects = [
    "Mathematik", "Deutsch", "Englisch", "Französisch", "Spanisch",
    "Geschichte", "Geographie", "Biologie", "Chemie", "Physik",
    "Sport", "Musik", "Kunst", "Informatik", "Religion", "Ethik",
    "Wirtschaft", "Politik"
  ];

  const addTeacherMutation = useMutation({
    mutationFn: async (teacherData: InsertTeacher) => {
      const response = await apiRequest('POST', '/api/teachers', teacherData);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Lehrer eingereicht!",
        description: "Der Lehrer wurde eingereicht und wartet auf Admin-Genehmigung.",
      });
      onClose();
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Fehler",
        description: error.message || "Der Lehrer konnte nicht erstellt werden.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      subject: "",
      emoji: "",
      schoolId: "",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.subject || !formData.schoolId) {
      toast({
        title: "Fehlende Angaben",
        description: "Bitte fülle alle Pflichtfelder aus.",
        variant: "destructive",
      });
      return;
    }

    const submitData = {
      name: formData.name,
      subject: formData.subject,
      emoji: formData.emoji || getSubjectEmoji(formData.subject),
      schoolId: parseInt(formData.schoolId),
    };

    addTeacherMutation.mutate(submitData);
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      
      // Auto-set emoji when subject changes
      if (field === 'subject' && !prev.emoji) {
        newData.emoji = getSubjectEmoji(value);
      }
      
      return newData;
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Neuen Lehrer hinzufügen</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name" className="block font-medium text-gray-700 mb-2">
              Name *
            </Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              placeholder="z.B. Dr. Schmidt oder Frau Müller"
              required
            />
          </div>

          <div>
            <Label htmlFor="subject" className="block font-medium text-gray-700 mb-2">
              Fach *
            </Label>
            <Select value={formData.subject} onValueChange={(value) => handleChange('subject', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Fach auswählen" />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((subject) => (
                  <SelectItem key={subject} value={subject}>
                    {getSubjectEmoji(subject)} {subject}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="emoji" className="block font-medium text-gray-700 mb-2">
              Emoji (optional)
            </Label>
            <Input
              id="emoji"
              value={formData.emoji}
              onChange={(e) => handleChange('emoji', e.target.value)}
              placeholder={`Standard: ${getSubjectEmoji(formData.subject)}`}
              maxLength={2}
            />
          </div>

          <div>
            <Label htmlFor="schoolId" className="block font-medium text-gray-700 mb-2">
              Schule *
            </Label>
            <Select value={formData.schoolId} onValueChange={(value) => handleChange('schoolId', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Schule auswählen" />
              </SelectTrigger>
              <SelectContent>
                {schools.map((school) => (
                  <SelectItem key={school.id} value={school.id.toString()}>
                    {school.name} - {school.location}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>



          <div className="flex space-x-3 mt-6">
            <Button 
              type="button"
              variant="outline" 
              onClick={onClose} 
              className="flex-1"
              disabled={addTeacherMutation.isPending}
            >
              Abbrechen
            </Button>
            <Button 
              type="submit"
              className="flex-1 bg-primary hover:bg-primary/90"
              disabled={addTeacherMutation.isPending}
            >
              {addTeacherMutation.isPending ? "Wird erstellt..." : "Lehrer hinzufügen"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}