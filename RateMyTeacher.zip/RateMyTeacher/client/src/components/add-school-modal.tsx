import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { InsertSchool } from "@shared/schema";

interface AddSchoolModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AddSchoolModal({ isOpen, onClose }: AddSchoolModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    name: "",
    location: "",
    code: "",
    adminCode: "",
  });

  const addSchoolMutation = useMutation({
    mutationFn: async (schoolData: InsertSchool & { adminCode: string }) => {
      const response = await apiRequest('POST', '/api/schools', schoolData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Schule hinzugefügt!",
        description: "Die neue Schule wurde erfolgreich erstellt.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/schools'] });
      onClose();
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Fehler",
        description: error.message || "Die Schule konnte nicht erstellt werden.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      location: "",
      code: "",
      adminCode: "",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.location || !formData.adminCode) {
      toast({
        title: "Fehlende Angaben",
        description: "Bitte fülle alle Pflichtfelder aus.",
        variant: "destructive",
      });
      return;
    }

    addSchoolMutation.mutate(formData);
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Neue Schule hinzufügen</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name" className="block font-medium text-gray-700 mb-2">
              Schulname *
            </Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              placeholder="z.B. Gymnasium Musterstadt"
              required
            />
          </div>

          <div>
            <Label htmlFor="location" className="block font-medium text-gray-700 mb-2">
              Ort *
            </Label>
            <Input
              id="location"
              value={formData.location}
              onChange={(e) => handleChange('location', e.target.value)}
              placeholder="z.B. München"
              required
            />
          </div>

          <div>
            <Label htmlFor="code" className="block font-medium text-gray-700 mb-2">
              Schulcode (optional)
            </Label>
            <Input
              id="code"
              value={formData.code}
              onChange={(e) => handleChange('code', e.target.value)}
              placeholder="z.B. GYM-MUC"
            />
          </div>

          <div>
            <Label htmlFor="adminCode" className="block font-medium text-gray-700 mb-2">
              Admin-Code *
            </Label>
            <Input
              id="adminCode"
              type="password"
              value={formData.adminCode}
              onChange={(e) => handleChange('adminCode', e.target.value)}
              placeholder="Admin-Code eingeben"
              required
            />
            <p className="text-xs text-gray-500 mt-1">
              Kontaktiere einen Administrator für den Code
            </p>
          </div>

          <div className="flex space-x-3 mt-6">
            <Button 
              type="button"
              variant="outline" 
              onClick={onClose} 
              className="flex-1"
              disabled={addSchoolMutation.isPending}
            >
              Abbrechen
            </Button>
            <Button 
              type="submit"
              className="flex-1 bg-primary hover:bg-primary/90"
              disabled={addSchoolMutation.isPending}
            >
              {addSchoolMutation.isPending ? "Wird erstellt..." : "Schule hinzufügen"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}