import { useState } from "react";
import { ArrowLeft, Eye, MessageCircle, Plus, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Header } from "@/components/header";
import { StarRating } from "@/components/star-rating";
import { RatingModal } from "@/components/rating-modal";
import { formatRating, formatTimeAgo, getCategoryIcon, getCategoryLabel, getGradientClass, getBadgeColor, getBadgeText } from "@/lib/utils";
import type { TeacherWithStats, Comment } from "@shared/schema";
import { Link } from "wouter";

export default function TeacherProfilePage() {
  const [, params] = useRoute("/teacher/:id");
  const teacherId = params?.id ? parseInt(params.id) : null;
  const [ratingModalOpen, setRatingModalOpen] = useState(false);
  const [selectedSchool, setSelectedSchool] = useState<number | null>(null);

  const { data: teacher, isLoading } = useQuery<TeacherWithStats>({
    queryKey: [`/api/teachers/${teacherId}`],
    enabled: !!teacherId,
  });

  const { data: comments = [] } = useQuery<Comment[]>({
    queryKey: [`/api/teachers/${teacherId}/comments`],
    enabled: !!teacherId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-light">
        <Header 
          selectedSchool={selectedSchool}
          onSchoolChange={setSelectedSchool}
          onRateClick={() => {}}
        />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-48 mb-6"></div>
            <div className="h-64 bg-gray-200 rounded mb-6"></div>
            <div className="h-48 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!teacher) {
    return (
      <div className="min-h-screen bg-light">
        <Header 
          selectedSchool={selectedSchool}
          onSchoolChange={setSelectedSchool}
          onRateClick={() => {}}
        />
        <div className="max-w-4xl mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Lehrer nicht gefunden</h1>
          <p className="text-gray-600 mb-6">Der gesuchte Lehrer existiert nicht oder wurde entfernt.</p>
          <Link href="/">
            <Button>Zurück zur Startseite</Button>
          </Link>
        </div>
      </div>
    );
  }

  const categories = [
    { key: 'explainsWell', value: teacher.categoryAverages.explainsWell },
    { key: 'fairGrading', value: teacher.categoryAverages.fairGrading },
    { key: 'humorLevel', value: teacher.categoryAverages.humorLevel },
    { key: 'homeworkAmount', value: teacher.categoryAverages.homeworkAmount },
    { key: 'outfitRating', value: teacher.categoryAverages.outfitRating },
    { key: 'chillFactor', value: teacher.categoryAverages.chillFactor },
  ];

  const subjectIndex = teacher.subject.charCodeAt(0) % 6;
  const badgeColor = getBadgeColor(teacher.averageRating || 0);
  const badgeText = getBadgeText(teacher.averageRating || 0);

  return (
    <div className="min-h-screen bg-background">
      <Header 
        selectedSchool={selectedSchool}
        onSchoolChange={setSelectedSchool}
        onRateClick={() => setRatingModalOpen(true)}
      />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <Link href="/">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Zurück zur Übersicht
          </Button>
        </Link>

        {/* Teacher Header */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center space-x-6">
                <div className={`w-24 h-24 ${getGradientClass(subjectIndex)} rounded-2xl flex items-center justify-center text-4xl`}>
                  {teacher.emoji}
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-dark mb-2">{teacher.name}</h1>
                  <p className="text-xl text-gray-600 mb-3">{teacher.subject}</p>
                  <p className="text-sm text-gray-500 mb-4">{teacher.schoolName}</p>
                  
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center">
                      <StarRating rating={teacher.averageRating || 0} size="lg" />
                      <span className="ml-3 text-2xl font-bold text-gray-900">
                        {formatRating(teacher.averageRating || 0)}
                      </span>
                    </div>
                    <span className="text-gray-500">
                      ({teacher.totalRatings} Bewertungen)
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col items-end space-y-3">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${badgeColor}`}>
                  {badgeText}
                </span>
                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <span className="flex items-center">
                    <Eye className="w-4 h-4 mr-1" />
                    {teacher.views} Views
                  </span>
                  <span className="flex items-center">
                    <MessageCircle className="w-4 h-4 mr-1" />
                    {teacher.commentCount} Kommentare
                  </span>
                </div>
                <div className="flex space-x-2">
                  <Button
                    onClick={() => setRatingModalOpen(true)}
                    className="bg-primary hover:bg-primary/90"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Bewerten
                  </Button>
                  <Button variant="outline" size="icon">
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Rating Categories */}
          <div className="lg:col-span-2">
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Bewertungskategorien</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {categories.map(({ key, value }) => (
                    <div key={key} className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <span className="text-2xl">{getCategoryIcon(key)}</span>
                          <span className="font-medium text-gray-700">{getCategoryLabel(key)}</span>
                        </div>
                        <span className="text-lg font-bold text-gray-900">
                          {formatRating(value)}
                        </span>
                      </div>
                      <StarRating rating={value} size="md" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Comments Section */}
            <Card>
              <CardHeader>
                <CardTitle>Kommentare ({comments.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {comments.length > 0 ? (
                  <div className="space-y-4">
                    {comments.map((comment) => (
                      <div key={comment.id} className="p-4 bg-gray-50 rounded-lg">
                        <p className="text-gray-800 mb-2">{comment.content}</p>
                        <p className="text-xs text-gray-500">
                          {comment.createdAt ? formatTimeAgo(new Date(comment.createdAt)) : 'Kürzlich'}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <MessageCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">Noch keine Kommentare vorhanden.</p>
                    <p className="text-sm text-gray-400">Sei der Erste und bewerte diesen Lehrer!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Stats Sidebar */}
          <div className="lg:col-span-1">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Statistiken</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Gesamtbewertung</span>
                  <span className="font-bold text-lg">{formatRating(teacher.averageRating || 0)}</span>
                </div>
                <Separator />
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Anzahl Bewertungen</span>
                  <span className="font-bold text-lg">{teacher.totalRatings}</span>
                </div>
                <Separator />
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Profilaufrufe</span>
                  <span className="font-bold text-lg">{teacher.views}</span>
                </div>
                <Separator />
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Letzte Bewertung</span>
                  <span className="font-bold text-sm">
                    {teacher.lastRated ? formatTimeAgo(new Date(teacher.lastRated)) : 'Nie'}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Aktionen</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  onClick={() => setRatingModalOpen(true)}
                  className="w-full bg-primary hover:bg-primary/90"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Bewertung abgeben
                </Button>
                <Button variant="outline" className="w-full">
                  <Share2 className="w-4 h-4 mr-2" />
                  Profil teilen
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Rating Modal */}
      <RatingModal
        isOpen={ratingModalOpen}
        onClose={() => setRatingModalOpen(false)}
        teacher={teacher}
      />
    </div>
  );
}
