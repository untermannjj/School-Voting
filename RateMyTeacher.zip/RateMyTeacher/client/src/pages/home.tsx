import { useState, useMemo } from "react";
import { Search, Filter, Home, Trophy, Flame, BarChart3, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/header";
import { TeacherCard } from "@/components/teacher-card";
import { Sidebar } from "@/components/sidebar";
import { RatingModal } from "@/components/rating-modal";
import type { Teacher } from "@shared/schema";
import { Link, useLocation } from "wouter";

type TabType = "all" | "rankings" | "weekly" | "battle";

export default function HomePage() {
  const [, setLocation] = useLocation();
  const [selectedSchool, setSelectedSchool] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [activeTab, setActiveTab] = useState<TabType>("all");
  const [ratingModalOpen, setRatingModalOpen] = useState(false);
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);

  // Fetch teachers
  const { data: teachers = [] } = useQuery<Teacher[]>({
    queryKey: ["/api/teachers", { schoolId: selectedSchool, subject: selectedSubject, search: searchQuery }],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedSchool) params.append('schoolId', selectedSchool.toString());
      if (selectedSubject && selectedSubject !== "all") params.append('subject', selectedSubject);
      if (searchQuery) params.append('search', searchQuery);
      
      const response = await fetch(`/api/teachers?${params}`);
      return response.json();
    },
  });

  // Fetch subjects
  const { data: subjects = [] } = useQuery<string[]>({
    queryKey: ["/api/subjects"],
  });

  // Enhanced teachers with mock data for display
  const enhancedTeachers = useMemo(() => {
    return teachers.map(teacher => ({
      ...teacher,
      commentCount: Math.floor(Math.random() * 200) + 20,
      categoryAverages: {
        explainsWell: Math.random() * 2 + 3,
        fairGrading: Math.random() * 2 + 3,
        humorLevel: Math.random() * 2 + 3,
        homeworkAmount: Math.random() * 2 + 2,
        outfitRating: Math.random() * 2 + 3,
        chillFactor: Math.random() * 2 + 3,
      }
    }));
  }, [teachers]);

  const tabs = [
    { id: "all", label: "Alle Lehrer", icon: Home },
    { id: "rankings", label: "Rankings", icon: Trophy },
    { id: "weekly", label: "Top der Woche", icon: Flame },
    { id: "battle", label: "School Battle", icon: BarChart3 },
  ];

  const handleTeacherClick = (teacher: Teacher) => {
    setLocation(`/teacher/${teacher.id}`);
  };

  const handleRateClick = () => {
    setRatingModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        selectedSchool={selectedSchool}
        onSchoolChange={setSelectedSchool}
        onRateClick={handleRateClick}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="mb-8">
          <nav className="flex space-x-8">
            {tabs.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id as TabType)}
                className={`px-4 py-2 font-medium text-sm transition-colors flex items-center ${
                  activeTab === id
                    ? "text-primary border-b-2 border-primary"
                    : "text-gray-500 hover:text-primary"
                }`}
              >
                <Icon className="w-4 h-4 mr-2" />
                {label}
              </button>
            ))}
          </nav>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Search and Filter */}
            <div className="mb-6 flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  type="text"
                  placeholder="Lehrer suchen..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 py-3 border-gray-200 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent"
                />
              </div>
              <div className="flex gap-2">
                <Select value={selectedSubject || undefined} onValueChange={setSelectedSubject}>
                  <SelectTrigger className="w-40 py-3 border-gray-200 rounded-xl">
                    <SelectValue placeholder="Alle Fächer" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle Fächer</SelectItem>
                    {subjects.map((subject) => (
                      <SelectItem key={subject} value={subject}>
                        {subject}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  variant="outline"
                  size="icon"
                  className="px-4 py-3 bg-gray-100 rounded-xl hover:bg-gray-200"
                >
                  <Filter className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Teacher Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {enhancedTeachers.map((teacher) => (
                <TeacherCard
                  key={teacher.id}
                  teacher={teacher}
                  onClick={() => handleTeacherClick(teacher)}
                />
              ))}
            </div>

            {/* Load More Button */}
            {enhancedTeachers.length > 0 && (
              <div className="text-center">
                <Button
                  variant="outline"
                  className="px-6 py-3 border-gray-200 hover:bg-gray-50"
                >
                  Mehr Lehrer laden
                  <Filter className="w-4 h-4 ml-2" />
                </Button>
              </div>
            )}

            {/* Empty State */}
            {enhancedTeachers.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">Keine Lehrer gefunden</h3>
                <p className="text-gray-500">
                  Versuche deine Suchkriterien zu ändern oder wähle eine andere Schule aus.
                </p>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Sidebar />
          </div>
        </div>
      </main>

      {/* Floating Action Button */}
      <Button
        onClick={handleRateClick}
        className="fixed bottom-6 right-6 w-14 h-14 bg-primary text-white rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200 z-40"
        size="icon"
      >
        <Plus className="w-6 h-6" />
      </Button>

      {/* Rating Modal */}
      <RatingModal
        isOpen={ratingModalOpen}
        onClose={() => setRatingModalOpen(false)}
        teacher={selectedTeacher}
      />
    </div>
  );
}
