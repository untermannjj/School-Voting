import { useState } from "react";
import { Trophy, Medal, Award, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/header";
import { StarRating } from "@/components/star-rating";
import { formatRating, getGradientClass } from "@/lib/utils";
import type { RankingEntry } from "@shared/schema";
import { Link } from "wouter";

export default function RankingsPage() {
  const [selectedSchool, setSelectedSchool] = useState<number | null>(null);

  const { data: topTeachers = [] } = useQuery<RankingEntry[]>({
    queryKey: ["/api/rankings/top-teachers"],
  });

  const { data: weeklyTop = [] } = useQuery<RankingEntry[]>({
    queryKey: ["/api/rankings/weekly-top"],
  });

  const { data: schoolRankings = [] } = useQuery<Array<{ school: any; averageRating: number }>>({
    queryKey: ["/api/rankings/schools"],
  });

  const getRankIcon = (position: number) => {
    switch (position) {
      case 1:
        return <Trophy className="w-6 h-6 text-yellow-500" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-400" />;
      case 3:
        return <Award className="w-6 h-6 text-amber-600" />;
      default:
        return <span className="w-6 h-6 flex items-center justify-center text-gray-500 font-bold">{position}</span>;
    }
  };

  const getTrendIcon = (change: number) => {
    if (change > 0) return <TrendingUp className="w-4 h-4 text-green-500" />;
    if (change < 0) return <TrendingDown className="w-4 h-4 text-red-500" />;
    return <Minus className="w-4 h-4 text-gray-400" />;
  };

  const RankingCard = ({ entries, title, description }: { entries: RankingEntry[], title: string, description: string }) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Trophy className="w-5 h-5 mr-2 text-secondary" />
          {title}
        </CardTitle>
        <p className="text-sm text-gray-500">{description}</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {entries.map((entry, index) => {
            const position = index + 1;
            const subjectIndex = entry.teacher.subject.charCodeAt(0) % 6;
            
            return (
              <div 
                key={entry.teacher.id}
                className={`flex items-center space-x-4 p-4 rounded-lg transition-colors hover:bg-gray-50 ${
                  position <= 3 ? 'bg-gradient-to-r from-secondary/5 to-transparent' : 'bg-gray-50'
                }`}
              >
                <div className="flex items-center justify-center w-10">
                  {getRankIcon(position)}
                </div>
                
                <div className={`w-12 h-12 ${getGradientClass(subjectIndex)} rounded-xl flex items-center justify-center text-lg`}>
                  {entry.teacher.emoji}
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <h3 className="font-semibold text-gray-900">{entry.teacher.name}</h3>
                    <span className="text-sm text-gray-500">•</span>
                    <span className="text-sm text-gray-500">{entry.teacher.subject}</span>
                  </div>
                  <div className="flex items-center space-x-2 mt-1">
                    <StarRating rating={entry.teacher.averageRating || 0} size="sm" />
                    <span className="text-sm text-gray-600">{formatRating(entry.teacher.averageRating || 0)}</span>
                    <span className="text-xs text-gray-400">({entry.teacher.totalRatings} Bewertungen)</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">{entry.school.name}</p>
                </div>
                
                <div className="flex items-center space-x-2">
                  {getTrendIcon(entry.rankChange)}
                  <span className={`text-sm font-medium ${
                    entry.rankChange > 0 ? 'text-green-600' : 
                    entry.rankChange < 0 ? 'text-red-600' : 'text-gray-500'
                  }`}>
                    {entry.rankChange > 0 ? '+' : ''}{entry.rankChange}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background">
      <Header 
        selectedSchool={selectedSchool}
        onSchoolChange={setSelectedSchool}
        onRateClick={() => {}}
      />

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-dark mb-2">Rankings & Bestenlisten</h1>
              <p className="text-gray-600">Entdecke die beliebtesten und besten bewerteten Lehrer</p>
            </div>
            <Link href="/">
              <Button variant="outline">Zurück zur Startseite</Button>
            </Link>
          </div>
        </div>

        <Tabs defaultValue="overall" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overall">Gesamtrankings</TabsTrigger>
            <TabsTrigger value="weekly">Wöchentliche Top</TabsTrigger>
            <TabsTrigger value="schools">School Battle</TabsTrigger>
          </TabsList>

          <TabsContent value="overall" className="space-y-6">
            <RankingCard 
              entries={topTeachers}
              title="Die besten Lehrer aller Zeiten"
              description="Basierend auf Gesamtbewertung und Anzahl der Bewertungen"
            />
          </TabsContent>

          <TabsContent value="weekly" className="space-y-6">
            <RankingCard 
              entries={weeklyTop}
              title="Top Lehrer dieser Woche"
              description="Die am besten bewerteten Lehrer der letzten 7 Tage"
            />
          </TabsContent>

          <TabsContent value="schools" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Trophy className="w-5 h-5 mr-2 text-primary" />
                  School Battle Rankings
                </CardTitle>
                <p className="text-sm text-gray-500">Schulen sortiert nach durchschnittlicher Lehrerbewertung</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {schoolRankings.map((ranking, index) => {
                    const position = index + 1;
                    const percentage = (ranking.averageRating / 5) * 100;
                    const colors = ['bg-primary', 'bg-accent', 'bg-secondary', 'bg-gray-400'];
                    
                    return (
                      <div 
                        key={ranking.school.id}
                        className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center justify-center w-10">
                            {getRankIcon(position)}
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">{ranking.school.name}</h3>
                            <p className="text-sm text-gray-500">{ranking.school.location}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-4">
                          <div className="text-right">
                            <div className="font-bold text-lg">{formatRating(ranking.averageRating)}</div>
                            <div className="text-xs text-gray-500">Durchschnitt</div>
                          </div>
                          <div className="w-24 h-3 bg-gray-200 rounded-full">
                            <div 
                              className={`h-3 ${colors[index] || 'bg-gray-400'} rounded-full transition-all duration-300`}
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
