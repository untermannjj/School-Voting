import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatTimeAgo } from "@/lib/utils";
import { CheckCircle, XCircle, Clock, Shield } from "lucide-react";

interface PendingTeacher {
  id: number;
  name: string;
  subject: string;
  emoji: string;
  schoolId: number;
  submittedAt: string;
  school: {
    id: number;
    name: string;
    location: string;
  };
}

export default function AdminPage() {
  const [adminCode, setAdminCode] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: pendingTeachers = [], isLoading, refetch } = useQuery<PendingTeacher[]>({
    queryKey: ["/api/admin/pending-teachers", adminCode],
    queryFn: async () => {
      if (!isAuthenticated) return [];
      const response = await fetch(`/api/admin/pending-teachers?adminCode=${adminCode}`);
      if (!response.ok) throw new Error("Failed to fetch pending teachers");
      return response.json();
    },
    enabled: isAuthenticated,
  });

  const approveMutation = useMutation({
    mutationFn: async (teacherId: number) => {
      const response = await apiRequest('POST', `/api/admin/approve-teacher/${teacherId}`, {
        adminCode,
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Lehrer genehmigt",
        description: data.message,
      });
      refetch();
      queryClient.invalidateQueries({ queryKey: ['/api/teachers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/subjects'] });
    },
    onError: (error: any) => {
      toast({
        title: "Fehler",
        description: error.message || "Genehmigung fehlgeschlagen",
        variant: "destructive",
      });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async (teacherId: number) => {
      const response = await apiRequest('POST', `/api/admin/reject-teacher/${teacherId}`, {
        adminCode,
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Lehrer abgelehnt",
        description: data.message,
      });
      refetch();
    },
    onError: (error: any) => {
      toast({
        title: "Fehler",
        description: error.message || "Ablehnung fehlgeschlagen",
        variant: "destructive",
      });
    },
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!adminCode) {
      toast({
        title: "Fehler",
        description: "Bitte Admin-Code eingeben",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch(`/api/admin/pending-teachers?adminCode=${adminCode}`);
      if (response.ok) {
        setIsAuthenticated(true);
        toast({
          title: "Anmeldung erfolgreich",
          description: "Willkommen im Admin-Bereich",
        });
      } else {
        toast({
          title: "Anmeldung fehlgeschlagen",
          description: "Ungültiger Admin-Code",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Fehler",
        description: "Verbindungsfehler",
        variant: "destructive",
      });
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mb-4">
              <Shield className="h-6 w-6 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold">Admin-Bereich</CardTitle>
            <CardDescription>
              Melden Sie sich an, um eingereichte Lehrer zu verwalten
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label htmlFor="adminCode">Admin-Code</Label>
                <Input
                  id="adminCode"
                  type="password"
                  value={adminCode}
                  onChange={(e) => setAdminCode(e.target.value)}
                  placeholder="Admin-Code eingeben"
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Anmelden
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Admin-Bereich</h1>
            <p className="text-gray-600 mt-2">Eingereichte Lehrer verwalten</p>
          </div>
          <Button
            variant="outline"
            onClick={() => {
              setIsAuthenticated(false);
              setAdminCode("");
            }}
          >
            Abmelden
          </Button>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Lade eingereichte Lehrer...</p>
          </div>
        ) : pendingTeachers.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Keine ausstehenden Genehmigungen
              </h3>
              <p className="text-gray-600">
                Alle eingereichten Lehrer wurden bereits bearbeitet.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {pendingTeachers.map((teacher) => (
              <Card key={teacher.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="text-2xl">{teacher.emoji}</div>
                      <div>
                        <CardTitle className="text-lg">{teacher.name}</CardTitle>
                        <CardDescription>{teacher.subject}</CardDescription>
                      </div>
                    </div>
                    <Badge variant="secondary">
                      <Clock className="h-3 w-3 mr-1" />
                      Ausstehend
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Schule</p>
                      <p className="text-sm text-gray-600">
                        {teacher.school.name} - {teacher.school.location}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">Eingereicht</p>
                      <p className="text-sm text-gray-600">
                        {formatTimeAgo(new Date(teacher.submittedAt))}
                      </p>
                    </div>
                    <div className="flex space-x-2 pt-2">
                      <Button
                        onClick={() => approveMutation.mutate(teacher.id)}
                        disabled={approveMutation.isPending || rejectMutation.isPending}
                        className="flex-1 bg-green-600 hover:bg-green-700"
                        size="sm"
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Genehmigen
                      </Button>
                      <Button
                        onClick={() => rejectMutation.mutate(teacher.id)}
                        disabled={approveMutation.isPending || rejectMutation.isPending}
                        variant="destructive"
                        className="flex-1"
                        size="sm"
                      >
                        <XCircle className="h-4 w-4 mr-1" />
                        Ablehnen
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}