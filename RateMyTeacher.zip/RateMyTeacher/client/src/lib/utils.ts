import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatRating(rating: number): string {
  return rating.toFixed(1);
}

export function getStarRating(rating: number): { full: number; half: boolean; empty: number } {
  const full = Math.floor(rating);
  const half = rating - full >= 0.5;
  const empty = 5 - full - (half ? 1 : 0);
  
  return { full, half, empty };
}

export function formatTimeAgo(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  
  const minutes = Math.floor(diff / (1000 * 60));
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  
  if (minutes < 60) {
    return `Vor ${minutes} Min.`;
  } else if (hours < 24) {
    return `Vor ${hours} Std.`;
  } else if (days < 7) {
    return `Vor ${days} Tag${days !== 1 ? 'en' : ''}`;
  } else {
    return date.toLocaleDateString('de-DE');
  }
}

export function getSubjectEmoji(subject: string): string {
  const emojiMap: Record<string, string> = {
    'Mathematik': '🧮',
    'Deutsch': '📚',
    'Englisch': '🇬🇧',
    'Französisch': '🇫🇷',
    'Spanisch': '🇪🇸',
    'Geschichte': '📜',
    'Geographie': '🌍',
    'Biologie': '🧬',
    'Chemie': '🧪',
    'Physik': '⚛️',
    'Sport': '🏃‍♂️',
    'Musik': '🎵',
    'Kunst': '🎨',
    'Informatik': '💻',
    'Religion': '⛪',
    'Ethik': '🤝',
    'Wirtschaft': '💼',
    'Politik': '🏛️',
  };
  
  return emojiMap[subject] || '👨‍🏫';
}

export function generateUserFingerprint(): string {
  // Simple fingerprinting for demo purposes
  // In production, use more sophisticated methods
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  ctx?.fillText('fingerprint', 0, 0);
  const canvasFingerprint = canvas.toDataURL();
  
  const screenFingerprint = `${screen.width}x${screen.height}x${screen.colorDepth}`;
  const timezoneFingerprint = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const languageFingerprint = navigator.language;
  
  const combined = `${canvasFingerprint}-${screenFingerprint}-${timezoneFingerprint}-${languageFingerprint}`;
  
  // Simple hash function
  let hash = 0;
  for (let i = 0; i < combined.length; i++) {
    const char = combined.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  
  return Math.abs(hash).toString(36);
}

export function getCategoryIcon(category: string): string {
  const iconMap: Record<string, string> = {
    'explainsWell': '💡',
    'fairGrading': '⚖️',
    'humorLevel': '😄',
    'homeworkAmount': '📝',
    'outfitRating': '👗',
    'chillFactor': '😎',
  };
  
  return iconMap[category] || '⭐';
}

export function getCategoryLabel(category: string): string {
  const labelMap: Record<string, string> = {
    'explainsWell': 'Erklärt gut',
    'fairGrading': 'Fair bei Noten',
    'humorLevel': 'Humor Level',
    'homeworkAmount': 'Hausaufgaben',
    'outfitRating': 'Outfit',
    'chillFactor': 'Chill-Faktor',
  };
  
  return labelMap[category] || category;
}

export function getGradientClass(index: number): string {
  const gradients = [
    'gradient-purple',
    'gradient-green',
    'gradient-blue',
    'gradient-red',
    'gradient-yellow',
    'gradient-pink'
  ];
  
  return gradients[index % gradients.length];
}

export function getBadgeColor(rating: number): string {
  if (rating >= 4.5) return 'bg-accent/10 text-accent';
  if (rating >= 4.0) return 'bg-secondary/10 text-secondary';
  if (rating >= 3.5) return 'bg-primary/10 text-primary';
  return 'bg-destructive/10 text-destructive';
}

export function getBadgeText(rating: number): string {
  if (rating >= 4.5) return 'Top Erklärer';
  if (rating >= 4.0) return 'Beliebt';
  if (rating >= 3.5) return 'Solide';
  return 'Harter Korrektor';
}
